# LoadingScreenSpriteFix -  Fixes the loading screen sprite and numbers overlapping each other

## What the fuck is this?

Have you ever seen some weird sprite overlapping on the loading screen prior to the splash art of Hopoo Games and Gearbox Publishing?.. No?... well i guess i'm a schizo.

If you have, this mod fixes the overlapping issue, in a hacky yet lightweight form.

## Care to be more of a nerd?

Instead of actually figuring out why the hell it happens, this mod adds a black background behind the Numbers and the loading sprite, this fixes the overlapping issue.

As Soon as the splash screen appears, the black background is removed, all hooks are removed and this mod destroys itself, i'd even unload it if i knew how.

## Why?

Idk i really hate seeing the spritework being mangled even if its such a small thing, its charming.

## Donations

Feel free to give me a coffee here

[![ko-fi](https://raw.githubusercontent.com/TeamMoonstorm/MoonstormSharedUtils/refs/heads/main/Docs/Readme/SupportNebby.png)](https://ko-fi.com/nebby1999)